package documenttypes;

public class SpreadsheetDocument extends Document {

    private String[] sheets;

    public SpreadsheetDocument(SpreadsheetDocument doc) {
        super(doc);
        this.sheets = doc.sheets;
    }

    public SpreadsheetDocument clone() {
        return new SpreadsheetDocument(this);
    }
}