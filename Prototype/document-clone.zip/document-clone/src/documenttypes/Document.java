package documenttypes;

public class Document implements Prototype {
    private String fileName;

    public Document (String fileName) {
        this.fileName = fileName;
    }

    public Document (Document doc) {
        this.fileName = doc.fileName;
    }
    public Document clone () {
        return new Document(this);
    }
}
