import documenttypes.Document;
import documenttypes.TextDocument;

public class Main {
    public static void main(String[] args) {
        TextDocument textDoc = new TextDocument("/var/tmp/file.txt", "Some test text");
        System.out.println(textDoc);
        TextDocument newDoc = textDoc.clone();
        System.out.println(newDoc);
    }
}